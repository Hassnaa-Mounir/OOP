﻿using Libaray_Ass2;
using System;
using System.Collections.Immutable;
using System.Drawing;
using System.Security.Cryptography.X509Certificates;

namespace Assignment_2_OOP
{
    internal class Program
    {
       
        #region   Overloading
        //public static int Sum(int x, int y) { return x + y; }

        //public static double Sum(int x, double y) { return x + y; }

        //public static double Sum(double x, int y) { return x + y; }

        //public static double Sum(double x,double y) { return x + y; }
        //public static int Sum(int x, int y, int z) { return x + y + z; }



        #endregion
        private static int boxingCount = 0;
       private static int unboxingCount = 0;
        static void Main(string[] args)
        {
            #region     Demo
            #region Indexer property
            //Note noteBook = new Note(3);
            //noteBook.AddPerson(0, "ahmed", 123);
            //noteBook.AddPerson(1, "Mona", 718);
            //noteBook.setnumbers("ahmed", 989);
            //noteBook["ahmed"] =123;
            //for (int i = 0; i < noteBook.Size; i++)
            //{
            //    Console.WriteLine(noteBook[i]);
            //}
            //for (int i = 0; i < noteBook.Size; i++)
            //{
            //    Console.WriteLine(noteBook["ahmed"]);

            //    break;
            //}
            #endregion

            #region Class
            //Car c1;
            ///// Declare for reference of type "Car" ,refering to null
            ///// CLR will Allocate 4bytes at stack for this reference 'c1'-->address
            ///// CLR will Allocate 0 bytes at Heap -->data of reference

            //c1 = new Car(154,"Hyndai");
            /////new
            ////1.Allocate required number of bytes for Allocated object at heap =16 bytes(4 int ,4, string ,8 double)
            ////2.intialize allocated bytes of each and every attribute with default value of data type
            ////3. call user_defined constructor [if exists]
            ////4. Assign Address of allocated object in heap to reference 'c1'

            //Console.WriteLine(c1.ToString());


            #endregion

            #region   Binding

            //TypeA typeA = new TypeE(2,4,6,1,7);       //indiect inhertance
            //typeA.product2();               // dynamic binding                                 
            //typeA.product();                //static  binding                         

            //TypeB typeB = new TypeE(2, 4, 6, 1, 7);     //indiect inhertance
            //typeB.product2();                 // dynamic binding                       
            //typeB.product();                  // static binding                        

            //TypeC typeC = new TypeE(2, 4, 6, 1, 7);     //indiect inhertance
            //typeC.product2();                  // dynamic binding                    
            //typeC.product();                   // static binding                        

            //TypeD typeD = new TypeE(2, 4, 6, 1, 7);     //diect inhertance
            //typeD.product2();                  // dynamic binding
            //typeD.product();                   // static binding


            #endregion

            #endregion


            #region     Assignment02_OOP

            ////////////////part 03
            #region part3 _ 1.	Design and implement a Class for the employees in a company:
            //Employee emp =new Employee(20190180,"hassnaa","HighLevel",5000, DateTime.Parse("2023/07/20"),"female");

            //emp.DisplayDataOfEmployee(); 
            #endregion

            #region 2.	Develop a Class to represent the Hiring Date Data:⮚	consisting of fields to hold the day, month and Years.


            // HiringDate hiredate = new HiringDate(20,7,2023);
            //Employee emp=new Employee(20190180, "hassnaa", "HighLevel", 5000, hiredate, "female");
            // emp.DisplayDataOfEmployee();

            #endregion

            #region   3.	We need to restrict the Gender field to be only M or F [Male or Female] 
            //HiringDate hiredate = new HiringDate(20, 7, 2023);

            //Gender gender =Gender.female;

            //Employee emp = new Employee(20190180, "hassnaa", "HighLevel", 5000, hiredate, gender);
            //emp.DisplayDataOfEmployee();

            #endregion


            #region    4.	Assign the following security privileges to the employee (guest, Developer, secretary and DBA) in a form of Enum
            //HiringDate hiredate = new HiringDate(20, 7, 2023);

            //Gender gender = Gender.female;
            //SecurityPrivilege privilege = SecurityPrivilege.Developer;
            //Employee emp = new Employee(20190180, "hassnaa", privilege, 5000, hiredate, gender);
            //emp.DisplayDataOfEmployee();
            #endregion


            #region  5.	We want to provide the Employee Class to represent Employee data in a string Form (override ToString ()), display employee salary in a currency format. [ use String.Format Function]
            //HiringDate hiredate = new HiringDate(20, 7, 2023);

            //Gender gender = Gender.female;
            //SecurityPrivilege privilege = SecurityPrivilege.Developer;
            //Employee emp = new Employee(20190180, "hassnaa", privilege, 5000, hiredate, gender);
            //Console.WriteLine(emp); 
            #endregion

            #region   6.	Create an array of Employees with size three a DBA, Guest and the third one is security officer who have full permissions. (Employee [] EmpArr;)
            //HiringDate hiredate1 = new HiringDate(20, 7, 2023);


            //Employee dba = new Employee(20190180, "hassnaa", SecurityPrivilege.DBA, 5000, hiredate1, Gender.f);
            //HiringDate hiredate2 = new HiringDate(15, 2, 2023);
            //Employee Guest = new Employee(20190454, "mahinaz", SecurityPrivilege.Guest, 9000, hiredate2, Gender.female);
            //HiringDate hiredate3 = new HiringDate(5, 8, 2022);
            //Employee securityOfficer = new Employee(20102411, "mohamed", SecurityPrivilege.Secretary, 7000, hiredate3, Gender.m);


            //Employee[] EmpArr = { dba, Guest, securityOfficer };

            //foreach (Employee emp in EmpArr)
            //{
            //    Console.WriteLine(emp);
            //    Console.WriteLine();
            //}


            ///////// another solution 
            ///by using indexer property
            ///

            // HiringDate hiredate1 = new HiringDate(20, 7, 2023);

            // int size = 3;
            // Employee[] arr = new Employee[size];
            // Employee dba = new Employee(20190180, "hassnaa", SecurityPrivilege.DBA, 5000, hiredate1, Gender.f);
            // arr[0]= dba;
            // HiringDate hiredate2 = new HiringDate(15, 2, 2023);
            // Employee Guest = new Employee(20190454, "mahinaz", SecurityPrivilege.Guest, 9000, hiredate2, Gender.female);
            // arr[1]= Guest;
            // HiringDate hiredate3 = new HiringDate(5, 8, 2022);
            // Employee securityOfficer = new Employee(20102411, "mohamed", SecurityPrivilege.Secretary, 7000, hiredate3, Gender.m);
            // arr[2]= securityOfficer;

            //// Console.WriteLine(arr[0]);

            // foreach (Employee emp in arr)
            // {
            //     Console.WriteLine(emp);
            //     Console.WriteLine();
            // }


            #endregion


            #region     7.	Sort the employees based on their hire date then Print the sorted array.

          
           // HiringDate hiredate1 = new HiringDate(20, 1, 2023);

           // int size = 3;
           // Employee[] arr = new Employee[size];
           // Employee dba = new Employee(20190180, "hassnaa", SecurityPrivilege.DBA, 5000, hiredate1, Gender.f);
           // arr[0] = dba;
           // HiringDate hiredate2 = new HiringDate(15, 2, 2023);
           // Employee Guest = new Employee(20190454, "mahinaz", SecurityPrivilege.Guest, 9000, hiredate2, Gender.female);
           // arr[1] = Guest;
           // HiringDate hiredate3 = new HiringDate(5, 8, 2022);
           // Employee securityOfficer = new Employee(20102411, "mohamed", SecurityPrivilege.Secretary, 7000, hiredate3, Gender.m);
           // arr[2] = securityOfficer;


           // Employee emp = new Employee(1,"emp",SecurityPrivilege.Guest,2000,hiredate2,Gender.m);
           // emp.sortEmployees(arr);
           // foreach (Employee employee in arr) { Console.WriteLine(employee); }


           // Console.WriteLine($"Boxing Counting = {boxingCount}");
           //Console.WriteLine($"UnBoxing Counting = {unboxingCount}");
            #endregion

            #endregion





        }
    }
}

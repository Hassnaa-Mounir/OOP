﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Libaray_Ass2
{

    #region    Demo
    #region Indexer Property

    //public class Note {

    //	#region Attributes
    //	private string[] names;
    //	private long[] numbers;
    //	private int size; 
    //	#endregion

    //	public int Size
    //	{
    //		get { return size; }
    //		set { size = value; }
    //	}

    //	#region Constructor
    //	public Note(int _size)
    //	{
    //		size = _size;
    //		names = new string[size];
    //		numbers = new long[size];
    //	}
    //	#endregion

    //	#region Setter,Getter
    //	public long Getnumbers(string name)
    //	{
    //		for (int i = 0; i < names.Length; i++)
    //		{
    //			if (names[i] == name)
    //			{
    //				return numbers[i];
    //				break;
    //			}
    //		}
    //		return -1;

    //	}

    //	public void setnumbers(string name, long number)
    //	{
    //		for (int i = 0; i < names.Length; i++)
    //		{
    //			if (names[i] == name)
    //			{
    //				numbers[i] = number;
    //				break;
    //			}
    //		}

    //	}
    //	#endregion

    //	#region Indexers
    //	public long this[string name]
    //	{
    //		get
    //		{
    //			for (int i = 0; i < names.Length; i++)
    //			{
    //				if (names[i] == name)
    //				{
    //					return numbers[i];
    //					break;
    //				}
    //			}
    //			return -1;

    //		}
    //		set
    //		{
    //			for (int i = 0; i < names.Length; i++)
    //			{
    //				if (names[i] == name)
    //				{
    //					numbers[i] = value;
    //					break;
    //				}
    //			}
    //		}
    //	} 
    //	public string this[int index] { // Read Only
    //		get {
    //			return $"position :{index } ,Name : {names[index]}";
    //		}

    //	}
    //	#endregion

    //	#region  methods
    //	public void AddPerson(uint position, string name, long number)
    //	{
    //		if (numbers.Length != 0 && names.Length != 0) // checking is not null arraies
    //		{
    //			if (position < size)
    //			{
    //				names[position] = name;
    //				numbers[position] = number;

    //			}

    //		}

    //	}
    //       #endregion
    //   }



    #endregion

    #region   Class Car
    //public class Car
    //{

    //    #region Attributes
    //    //private int id;
    //    //private string model;
    //    //private double speed;
    //    #endregion

    //    #region Properties
    //    //public int ID { get; set; }
    //    //public string Model { get; set; }
    //    //public double Speed { get; set; }
    //    #endregion

    //    #region    Constructors
    //    public Car(int _id, string _model, double speed)
    //    {
    //        id = _id;
    //        model = _model;
    //        this.speed = speed;
    //        Console.WriteLine("ctor 01");
    //    }
    //    public Car(int _id, string model) : this(_id, model, 180)/*constructor chaining*/
    //    {
    //        Console.WriteLine("ctor 02");
    //    }
    //    #endregion

    //    #region Methods
    //    //public override string ToString()
    //    //{
    //    //    return $"ID :{id} \n Model : {model} \nSpeed : {speed}";
    //    //} 
    //    #endregion


    //}

    #endregion

    #region   Ihertance Relationship
    //public class Child : Parent
    //{
    //    public int Z { get; set; }
    //    public Child(int x, int y, int z) : base(x, y)  //chaining constructor
    //    {
    //        Z = z;
    //    }

    //    #region two ways for overriding
    //    ////public override int product()
    //    ////{
    //    ////    return base.product() * Z;
    //    ////}
    //    //public new int product()
    //    //{
    //    //    return base.product() * Z;
    //    //}
    //    #endregion


    //} 
    #endregion


    #region   Associate Relationship

    //public class Order {
    //    private int code_id;
    //    private string buyerEmail;
    //    public decimal subTotal;
    //    public Product products;
    //    public int quantity;
    //    public int Code_id { get; set; }
    //    public string BuyerEmail { get; set; }
    //    public decimal SubTotal { get; set; }
    //    public Product Product { get; set; }
    //    public int  Quantity { get; set; }
    //    public Employee[]? employees { get; set; } //aggregation -->nullable (optional) not nessasary
    //    public Order(string BuyerEmail, Product products) //composite (nessasary)-->mandatory if make object from order must give product ,email of buyer
    //    {
    //        this.buyerEmail= BuyerEmail;
    //        this.products = products;
    //    }
    //    public Order(Product product)
    //    {
    //        products = product;
    //    }


    //}

    #endregion

    #region Inhertance
    //public class Parent {

    //    public int X { get; set; }
    //    public int Y { get; set; }
    //    public Parent(int x, int y)
    //    {
    //        this.Y = y;
    //        this.X = x;
    //    }

    //    public virtual int product() { return X * Y; }
    //    public override string ToString()
    //    {
    //        return $"X : {X} \nY :{Y}";
    //    }

    //}



    #endregion


    #region Associate Relationship
    //public class Product
    //{
    //    private int id;
    //    private string name;
    //    private string description;
    //    private double price;
    //    public int ID { get; set; }
    //    public string Name { get; set; }
    //    public string Description { get; set; }

    //    public double Price { get; set; }

    //    public Product(int id,string name,string description,double price)
    //    {
    //        this.id = id;   
    //        this.name = name;
    //        this.description = description;
    //        this.price = price;
    //    }

    //}

    //public class Employee 
    //{
    //    public int ID { get; set; }
    //    public int Name { get; set; }
    //    public int operations { get; set; }
    //}
    #endregion

    #region    Ploymorphism
    #region    Overriding

    #region   Parent Class
    //public class Parent
    //{
    //    #region  Automatic property
    //    public int X { get; set; }
    //    public int Y { get; set; }
    //    #endregion

    //    #region  Constructor
    //    public Parent(int _x, int _y)
    //    {
    //        X = _x;
    //        Y = _y;
    //    }
    //    #endregion

    //    #region   Methods
    //    public override string ToString() { return $"X : {X} \n Y :{Y}"; }
    //    // public virtual int product() { return X * Y; }
    //    public int product() { return X * Y; }
    //    #endregion

    //}
    #endregion

    #region  Child Class
    //public class Child : Parent
    //{
    //    #region  Automatic property
    //    public int Z { get; set; }
    //    #endregion

    //    #region  Constructor
    //    public Child(int _x, int _y, int _z) : base(_x, _y)
    //    {
    //        Z = _z;
    //    }
    //    #endregion

    //    #region   Methods
    //    public override string ToString() { return $"{base.ToString()} \n Z :{z}"; }
    //    //public override int product() { return base.product()*Z; }
    //    public new int product() { return base.product() * Z; }
    //    #endregion

    //} 
    #endregion

    #endregion


    #endregion

    #region   Binding

    //#region  Class of TypeA
    //public class TypeA
    //{
    //    private int x = 1;
    //    private int y = 2;
    //    public int A { get; set; }

    //    public TypeA(int a)
    //    {
    //        A = a;
    //    }
    //    public override string ToString()
    //    {
    //        return $"A : {A}";
    //    }
    //    public int product() { return x * y * A; }
    //    public virtual int product2() { return x * y * A; }
    //}
    //#endregion

    //#region   Class of TypeB
    //public class TypeB : TypeA
    //{

    //    public int B { get; set; }

    //    public TypeB(int a, int b) : base(a)
    //    {
    //        B = b;
    //    }
    //    public override string ToString()
    //    {
    //        return $"B : {B}";
    //    }
    //    public new int product() { return base.product() * B; }
    //    public override int product2() { return base.product2() * B; }
    //}
    //#endregion

    //#region   Class of TypeC
    //public class TypeC : TypeB
    //{
    //    public int C { get; set; }

    //    public TypeC(int a, int b, int c) : base(a, b)
    //    {
    //        C = c;
    //    }
    //    public override string ToString()
    //    {
    //        return $"C : {C}";
    //    }
    //    public new int product() { return base.product() * C; }
    //    public override int product2() { return base.product2() * C; }
    //}

    //#endregion

    //#region    Class of TypeD
    //public class TypeD : TypeC
    //{
    //    public int D { get; set; }

    //    public TypeD(int a, int b, int c, int d) : base(a, b, c)
    //    {
    //        D = d;
    //    }
    //    public override string ToString()
    //    {
    //        return $"D : {D}";
    //    }
    //    public new int product() { return base.product() * D; }
    //    public new virtual int product2() { return base.product2() * D; }
    //}


    //#endregion

    //#region   Class of TypeE
    //public class TypeE : TypeD
    //{
    //    public int E { get; set; }

    //    public TypeE(int a, int b, int c, int d, int e) : base(a, b, c, d)
    //    {
    //        E = e;
    //    }
    //    public override string ToString()
    //    {
    //        return $"E : {E}";
    //    }
    //    public new int product() { return base.product() * E; }
    //    public override int product2() { return base.product2() * E; }
    //}

    //#endregion



    #endregion



    #endregion

    #region    Assignment02_OOP
    ///////////////////part 03
    #region Part3_ 1.	Design and implement a Class for the employees in a company:
    //public class Employee
    //{

    //    public int ID;
    //    public string Name;
    //    public string securitylevel;
    //    public double salary;
    //    public DateTime hireDate;
    //    public string Gender;


    //    public Employee(int id, string name, string secuirtyLevel, double salary, DateTime hireDate, string gender)
    //    {
    //        ID = id;
    //        Name = name;
    //        securitylevel = secuirtyLevel;
    //        this.salary = salary;
    //        this.hireDate = hireDate;
    //        Gender = gender;
    //    }
    //    public void DisplayDataOfEmployee()
    //    {
    //        Console.WriteLine($"ID of employee is {ID}");
    //        Console.WriteLine($"Name of employee is {Name}");
    //        Console.WriteLine($"SecuiretyLevel of employee is {securitylevel}");
    //        Console.WriteLine($"salary of employee is {salary}");
    //        Console.WriteLine($"HireDate of employee is {hireDate}");
    //        Console.WriteLine($"Gender of employee is {Gender}");
    //    }
    //}
    #endregion

    #region   2.	Develop a Class to represent the Hiring Date Data:
    //public class HiringDate {
    //    private int day;

    //    public int Day
    //    {
    //        get; set;
    //    }
    //    private int month;

    //    public int Month
    //    {
    //        get; set;
    //    }
    //    private int year;

    //    public int Year
    //    {
    //        get; set;
    //    }

    //    //constructor 
    //    public HiringDate(int day, int month, int year)
    //    {
    //        Day = day;
    //        Month = month;
    //        Year = year;
    //    }
    //  //  public void DisplayHireDate() { Console.WriteLine($"HireDate is {year}/{month}/{day}"); }

    //    public override string ToString()
    //    {        return $"{Year}/{Month}/{Day}";
    //        }
    //}
    //public class Employee
    //{

    //    public int ID;
    //    public string Name;
    //    public string securitylevel;
    //    public double salary;
    //    public string Gender;
    //    public HiringDate HD;

    //    public Employee(int id, string name, string secuirtyLevel, double salary, HiringDate hireDate, string gender)
    //    {
    //        ID = id;
    //        Name = name;
    //        securitylevel = secuirtyLevel;
    //        this.salary = salary;
    //        HD = hireDate;
    //        Gender = gender;
    //    }
    //    public void DisplayDataOfEmployee()
    //    {
    //        Console.WriteLine($"ID of employee is {ID}");
    //        Console.WriteLine($"Name of employee is {Name}");
    //        Console.WriteLine($"SecuiretyLevel of employee is {securitylevel}");
    //        Console.WriteLine($"salary of employee is {salary}");
    //        Console.WriteLine($"HireDate of employee is {HD}");
    //        Console.WriteLine($"Gender of employee is {Gender}");
    //    }
    //} 
    #endregion

    #region   3.	We need to restrict the Gender field to be only M or F [Male or Female] 
    // public enum Gender { male =1 ,m=1, female=2,f=2 }  

    //public class HiringDate
    //{
    //    private int day;

    //    public int Day
    //    {
    //        get; set;
    //    }
    //    private int month;

    //    public int Month
    //    {
    //        get; set;
    //    }
    //    private int year;

    //    public int Year
    //    {
    //        get; set;
    //    }

    //    //constructor 
    //    public HiringDate(int day, int month, int year)
    //    {
    //        Day = day;
    //        Month = month;
    //        Year = year;
    //    }
    //    //  public void DisplayHireDate() { Console.WriteLine($"HireDate is {year}/{month}/{day}"); }

    //    public override string ToString()
    //    {
    //        return $"{Year}/{Month}/{Day}";
    //    }
    //}
    //public class Employee
    //{

    //    public int ID;
    //    public string Name;
    //    public string securitylevel;
    //    public double salary;
    //    public Gender gender;
    //    public HiringDate HD;
    //    public Gender Gender { get; set; }
    //    public Employee(int id, string name, string secuirtyLevel, double salary, HiringDate hireDate, Gender gender)
    //    {
    //        ID = id;
    //        Name = name;
    //        securitylevel = secuirtyLevel;
    //        this.salary = salary;
    //        HD = hireDate;
    //        Gender = gender;    
    //    }
    //    public void DisplayDataOfEmployee()
    //    {
    //        Console.WriteLine($"ID of employee is {ID}");
    //        Console.WriteLine($"Name of employee is {Name}");
    //        Console.WriteLine($"SecuiretyLevel of employee is {securitylevel}");
    //        Console.WriteLine($"salary of employee is {salary}");
    //        Console.WriteLine($"HireDate of employee is {HD}");
    //        Console.WriteLine($"Gender of employee is {Gender}");
    //    }
    //} 
    #endregion

    #region   4.	Assign the following security privileges to the employee (guest, Developer, secretary and DBA) in a form of Enum
    //public enum Gender { male = 1, m = 1, female = 2, f = 2 }
    //public enum SecurityPrivilege {
    //    Guest,
    //    Developer,
    //    Secretary,
    //    DBA
    //}
    //public class HiringDate
    //{
    //    private int day;

    //    public int Day
    //    {
    //        get; set;
    //    }
    //    private int month;

    //    public int Month
    //    {
    //        get; set;
    //    }
    //    private int year;

    //    public int Year
    //    {
    //        get; set;
    //    }

    //    //constructor 
    //    public HiringDate(int day, int month, int year)
    //    {
    //        Day = day;
    //        Month = month;
    //        Year = year;
    //    }
    //    //  public void DisplayHireDate() { Console.WriteLine($"HireDate is {year}/{month}/{day}"); }

    //    public override string ToString()
    //    {
    //        return $"{Year}/{Month}/{Day}";
    //    }
    //}
    //public class Employee
    //{

    //    public int ID;
    //    public string Name;
    //    public SecurityPrivilege securitylevel;
    //    public double salary;
    //    public Gender gender;
    //    public HiringDate HD;
    //    public Gender Gender { get; set; }
    //    public SecurityPrivilege Securitylevel { get; set; }
    //    public Employee(int id, string name, SecurityPrivilege secuirtyLevel, double salary, HiringDate hireDate, Gender gender)
    //    {
    //        ID = id;
    //        Name = name;
    //        Securitylevel = secuirtyLevel;
    //        this.salary = salary;
    //        HD = hireDate;
    //        Gender = gender;
    //    }
    //    public void DisplayDataOfEmployee()
    //    {
    //        Console.WriteLine($"ID of employee is {ID}");
    //        Console.WriteLine($"Name of employee is {Name}");
    //        Console.WriteLine($"SecuiretyLevel of employee is {Securitylevel}");
    //        Console.WriteLine($"salary of employee is {salary}");
    //        Console.WriteLine($"HireDate of employee is {HD}");
    //        Console.WriteLine($"Gender of employee is {Gender}");
    //    }
    //} 
    #endregion

    #region   5.	We want to provide the Employee Class to represent Employee data in a string Form (override ToString ()), display employee salary in a currency format. [ use String.Format Function]
    //public enum Gender { male = 1, m = 1, female = 2, f = 2 }
    //public enum SecurityPrivilege
    //{
    //    Guest,
    //    Developer,
    //    Secretary,
    //    DBA
    //}
    //public class HiringDate
    //{
    //    private int day;

    //    public int Day
    //    {
    //        get; set;
    //    }
    //    private int month;

    //    public int Month
    //    {
    //        get; set;
    //    }
    //    private int year;

    //    public int Year
    //    {
    //        get; set;
    //    }

    //    //constructor 
    //    public HiringDate(int day, int month, int year)
    //    {
    //        Day = day;
    //        Month = month;
    //        Year = year;
    //    }
    //    //  public void DisplayHireDate() { Console.WriteLine($"HireDate is {year}/{month}/{day}"); }

    //    public override string ToString()
    //    {
    //        return $"{Year}/{Month}/{Day}";
    //    }
    //}
    //public class Employee
    //{

    //    public int ID;
    //    public string Name;
    //    public SecurityPrivilege securitylevel;
    //    public double salary;
    //    public Gender gender;
    //    public HiringDate HD;

    //    public Gender Gender { get; set; }
    //    public SecurityPrivilege Securitylevel { get; set; }
    //    public Employee()
    //    {
    //        ID = 0;
    //        Name = " ";
    //        this.salary = salary;
    //    }
    //    public Employee(int id, string name, SecurityPrivilege secuirtyLevel, double salary, HiringDate hireDate, Gender gender)
    //    {
    //        ID = id;
    //        Name = name;
    //        Securitylevel = secuirtyLevel;
    //        this.salary = salary;
    //        HD = hireDate;
    //        Gender = gender;
    //    }


    //    public override string ToString()
    //    {
    //        return string.Format("Employee ID: {0}\nName: {1}\nSecurity Level: {2}\nSalary: {3:C}\nGender: {4}\nHire Date: {5}",
    //        ID, Name, Securitylevel, salary, Gender, HD);
    //    }


    //}
    #endregion

    #region    6.	Create an array of Employees with size three a DBA, Guest and the third one is security officer who have full permissions. (Employee [] EmpArr;)

    //public enum Gender { male = 1, m = 1, female = 2, f = 2 }
    //public enum SecurityPrivilege
    //{
    //    Guest,
    //    Developer,
    //    Secretary,
    //    DBA
    //}
    //public class HiringDate
    //{
    //    private int day;

    //    public int Day
    //    {
    //        get; set;
    //    }
    //    private int month;

    //    public int Month
    //    {
    //        get; set;
    //    }
    //    private int year;

    //    public int Year
    //    {
    //        get; set;
    //    }

    //    //constructor 
    //    public HiringDate(int day, int month, int year)
    //    {
    //        Day = day;
    //        Month = month;
    //        Year = year;
    //    }
    //    //  public void DisplayHireDate() { Console.WriteLine($"HireDate is {year}/{month}/{day}"); }

    //    public override string ToString()
    //    {
    //        return $"{Year}/{Month}/{Day}";
    //    }
    //}
    //public class Employee
    //{
    //    private Employee[] emp_arr = new Employee[3];
    //    private int iD;
    //    private string name;
    //    public SecurityPrivilege securitylevel;
    //    private double salary;
    //    public Gender gender;
    //    public HiringDate hd;
    //    public Employee this[uint index]
    //    {

    //        get { /*if (index < emp_arr.Length)*/ return emp_arr[index];/* else Console.WriteLine("Index is Out Of Range");*/ }
    //        set { if (index < emp_arr.Length) { emp_arr[index] = value; } else { Console.WriteLine("Index is Out Of Range"); } }
    //    }
    //    public int ID { get; set; }
    //    public string Name { get; set; }
    //    public double Salary { get; set; }
    //    public HiringDate HD { get; set; }
    //    public Gender Gender { get; set; }
    //    public SecurityPrivilege Securitylevel { get; set; }

    //    public Employee()
    //    {
    //        ID = 0;
    //        Name = " ";
    //        this.salary = salary;
    //    }
    //    public Employee(int id, string name, SecurityPrivilege secuirtyLevel, double salary, HiringDate hireDate, Gender gender)
    //    {
    //        ID = id;
    //        Name = name;
    //        Securitylevel = secuirtyLevel;
    //        this.salary = salary;
    //        HD = hireDate;
    //        Gender = gender;
    //    }


    //    public override string ToString()
    //    {
    //        return string.Format("Employee ID: {0}\nName: {1}\nSecurity Level: {2}\nSalary: {3:C}\nGender: {4}\nHire Date: {5}",
    //        ID, Name, Securitylevel, salary, Gender, HD);
    //    }


    //}

    #endregion

    #region    7.	Sort the employees based on their hire date then Print the sorted array.
    //public enum Gender { male = 1, m = 1, female = 2, f = 2 }
    //public enum SecurityPrivilege
    //{
    //    Guest,
    //    Developer,
    //    Secretary,
    //    DBA
    //}
    //public class HiringDate
    //{
    //    private int day;

    //    public int Day
    //    {
    //        get; set;
    //    }
    //    private int month;

    //    public int Month
    //    {
    //        get; set;
    //    }
    //    private int year;

    //    public int Year
    //    {
    //        get; set;
    //    }

    //    //constructor 
    //    public HiringDate(int day, int month, int year)
    //    {
    //        Day = day;
    //        Month = month;
    //        Year = year;
    //    }
    //    //  public void DisplayHireDate() { Console.WriteLine($"HireDate is {year}/{month}/{day}"); }
       
    //    public override string ToString()
    //    {
    //        return $"{Year}/{Month}/{Day}";
    //    }
      
    //}
   
    //public class Employee
    //{
    //    private Employee[] emp_arr = new Employee[3];
    //    private int iD;
    //    private string? name;
    //    public SecurityPrivilege securitylevel;
    //    private double salary;
    //    public Gender gender;
    //    public HiringDate? hd;
    //    public Employee this[uint index]
    //    {

    //        get { /*if (index < emp_arr.Length)*/ return emp_arr[index];/* else Console.WriteLine("Index is Out Of Range");*/ }
    //        set { if (index < emp_arr.Length) { emp_arr[index] = value; } else { Console.WriteLine("Index is Out Of Range"); } }
    //    }
    //    public int ID { get; set; }
    //    public string Name { get; set; }
    //    public double Salary { get; set; }
    //    public HiringDate HD { get; set; }
    //    public Gender Gender { get; set; }
    //    public SecurityPrivilege Securitylevel { get; set; }

    //    public Employee()
    //    {
    //        ID = 0;
    //        Name = " ";
    //        this.salary = salary;
    //    }
    //    public Employee(int id, string name, SecurityPrivilege secuirtyLevel, double salary, HiringDate hireDate, Gender gender)
    //    {
    //        ID = id;
    //        Name = name;
    //        Securitylevel = secuirtyLevel;
    //        this.salary = salary;
    //        HD = hireDate;
    //        Gender = gender;
    //    }


    //    public override string ToString()
    //    {
    //        return string.Format("Employee ID: {0}\nName: {1}\nSecurity Level: {2}\nSalary: {3:C}\nGender: {4}\nHire Date: {5}",
    //        ID, Name, Securitylevel, salary, Gender, HD);
    //    }
       
    //    public  HiringDate CompareHireDate(HiringDate Hd1, HiringDate Hd2)
    //    {

    //        if (Hd2.Year == Hd1.Year)
    //        {
    //            if (Hd2.Month == Hd1.Month) { if (Hd2.Day == Hd1.Day) return Hd1; else if (Hd2.Day != Hd1.Day) { if (Hd2.Day > Hd1.Day) return Hd1; else return Hd2; } }
    //            else if (Hd2.Month != Hd1.Month) { if (Hd2.Month > Hd1.Month) return Hd1; else return Hd2; }
    //        }

    //        else if (Hd2.Year != Hd1.Year) { if (Hd2.Year > Hd1.Year) return Hd1; else return Hd2; }
    //        else { return Hd1; }
    //        return Hd1;
    //    }
    //    public Employee[] sortEmployees(Employee[] employees) 
    //    {
    //        Employee[] emps= new Employee[employees.Length];
    //        Employee tmp = new Employee();

            
    //        for (int i = 0; i < employees.Length; i++)
    //        {
    //            for (int j = 1; j < employees.Length; j++)
    //            {

    //                if (i < employees.Length-1)
    //                {
    //                    if (emps is not null && employees is not null)
    //                    {
    //                        if (CompareHireDate(employees[i].HD, employees[j].HD) == employees[j].HD)
    //                        {  emps[i] = employees[j]; tmp = employees[i]; employees[i] = employees[j]; employees[j] = tmp; }
    //                        else { emps[i] = employees[i]; }

    //                    }
    //                }
    //            }
               
    //        }
    //        return emps;
    //    }

        
    //}


    #endregion

    #endregion
}

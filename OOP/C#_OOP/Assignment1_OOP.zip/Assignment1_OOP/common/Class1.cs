﻿namespace common
{
    public class Class1
    {

    }
}

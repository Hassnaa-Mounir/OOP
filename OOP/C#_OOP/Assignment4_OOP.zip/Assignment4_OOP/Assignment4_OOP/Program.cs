﻿using Assignment4_OOP.Assg4.Demo;
using Assignment4_OOP.Assg4.Project1;

namespace Assignment4_OOP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region  FirstProject
            //        Console.WriteLine("Enter coordinates for Point 1 (X Y Z):");
            //        if (TryReadCoordinates(out Point3D p1))
            //        {
            //            Console.WriteLine("Enter coordinates for Point 2 (X Y Z):");
            //            if (TryReadCoordinates(out Point3D p2))
            //            {

            //                Console.WriteLine($"Are P1 and P2 equal? {p1 == p2}");


            //                Point3D[] points = { p1, p2 };


            //                Array.Sort(points);


            //                Console.WriteLine("Sorted points:");
            //                foreach (var point in points)
            //                {
            //                    Console.WriteLine(point);
            //                }
            //            }
            //        }
            //    }

            //    // Helper method to read coordinates from user input
            //    static bool TryReadCoordinates(out Point3D point)
            //    {
            //        point = null;
            //        string input = Console.ReadLine();
            //        string[] coordinates = input.Split(' ');

            //        if (coordinates.Length == 3 && int.TryParse(coordinates[0], out int x) &&
            //            int.TryParse(coordinates[1], out int y) && int.TryParse(coordinates[2], out int z))
            //        {
            //            point = new Point3D(x, y, z);
            //            return true;
            //        }
            //        else
            //        {
            //            Console.WriteLine("Invalid input format. Please enter X Y Z coordinates separated by spaces.");
            //            return false;
            //        }


            #endregion

            #region SecondProject
            //double num1 = 10;
            //double num2 = 5;

            //// Calling methods without creating an instance of the class
            //Console.WriteLine($"Addition: {Maths.Add(num1, num2)}");
            //Console.WriteLine($"Subtraction: {Maths.Subtract(num1, num2)}");
            //Console.WriteLine($"Multiplication: {Maths.Multiply(num1, num2)}");
            //Console.WriteLine($"Division: {Maths.Divide(num1, num2)}"); 
            #endregion

            #region ThirdProject
            //Duration d1 = new Duration(1, 10, 15);
            //Duration d2 = new Duration(2, 10, 0);
            //Duration d3 = new Duration(666);


            //Duration sum = d1 + d2;
            //Console.WriteLine("Sum: " + sum);


            //Duration d4 = d1 + 7800;
            //Console.WriteLine("D4: " + d4);


            //Duration d5 = 666 + d3;
            //Console.WriteLine("D5: " + d5);


            //Duration incD1 = ++d1;
            //Console.WriteLine("Increased D1: " + incD1);

            ////Duration decD2 = --d2;
            ////Console.WriteLine("Decreased D2: " + decD2);

            //Duration sub = d1 - d2;
            //Console.WriteLine("Subtraction: " + sub);

            //Console.WriteLine("Is d1 greater than d2? " + (d1 > d2));
            //Console.WriteLine("Is d1 less than or equal to d2? " + (d1 <= d2));

            //DateTime dt = (DateTime)d1;
            //Console.WriteLine("DateTime equivalent of d1: " + dt); 
            #endregion

            //Utility utility1=new Utility(2,4);
            //Utility utility2 = new Utility(6, 9);

           // Console.WriteLine(Utility.Area(3.5));

            //Employee employee = new Employee();
            //employee.Salary = 1000;
            //employee.ID = 20199;
            //employee.Name = "Ahmed";
        }
}
}

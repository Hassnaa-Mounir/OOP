﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4_OOP.Assg4.Demo
{
    #region Operator Overloading ,Casting operator
    //internal class Complex
    //{
    //    public int Real { get; set; }
    //    public int Imag { get; set; }

    //    public override string ToString()
    //    {
    //        return $"{Real}+{Imag}i";
    //    }

    //    public static Complex operator +(Complex left,Complex right)
    //    {
    //        return new Complex()
    //        {
    //            Real = left.Real + right.Real,
    //            Imag = left.Imag + right.Imag
    //        };

    //        }

    //    public static Complex operator -(Complex left, Complex right)
    //    {
    //        return new Complex()
    //        {
    //            Real = (left?.Real??0) - (right?.Real??0),
    //            Imag = (left?.Imag??0) -( right?.Imag??0)
    //        };

    //    }
    //    public static Complex operator *(Complex left, Complex right)
    //    {
    //        return new Complex()
    //        {
    //            Real = (left?.Real ?? 0) * (right?.Real ?? 0),
    //            Imag = (left?.Imag ?? 0) * (right?.Imag ?? 0)
    //        };

    //    }
    //    public static bool operator >(Complex left, Complex right)
    //    {
    //        if ((left?.Real ?? 0) == (right?.Real ?? 0)) return left?.Imag > right?.Imag;
    //        else return right?.Real > left?.Real;
    //    }

    //    public static bool operator <(Complex left, Complex right)
    //    {
    //        if ((left?.Real ?? 0) == (right?.Real ?? 0)) return left?.Imag < right?.Imag;
    //        else return right?.Real < left?.Real;
    //    }

    //    public static Complex operator ++(Complex c) {
    //        return new Complex()
    //        {
    //            Real = (c?.Real ?? 0) + 1,
    //            Imag = (c?.Imag ?? 0)

    //        };
    //    }

    //   public static explicit operator string(Complex c) { return  c.ToString(); }

    //    public static implicit operator int(Complex c) { return (c?.Real ?? 0); }
    //} 
    #endregion

    #region Abstraction ,Static [property ,attribute ,constant]
    //internal abstract class Shape {
    //    public int Dim1 { get; set; }
    //    public int Dim2 { get; set; }

    //    public abstract double Area { get; }
    //    public abstract double CmToInch(double cm);
    //}
    //internal class BasedShape : Shape
    //{
    //    public BasedShape(int dim1,int dim2)
    //    {
    //        Dim1 = dim1;
    //        Dim2 = Dim2;
    //    }
    //    public override double Area => Dim1*Dim2 ;

    //    public override double CmToInch(double cm)
    //    {
    //        return cm/2.54 ;
    //    }

    //}
    //internal class Square:BasedShape {
    //    public Square(int dim):base(dim,dim)
    //    {

    //    }
    //    public override double Area => Dim2 * Dim1; }

    //internal class Circle : BasedShape {
    //    private static double pi=3.14;
    //   // private const double pi = 3.14;
    //    public double PI { get; set; }
    //    public Circle(int radius):base(radius,radius) 
    //    {

    //    }
    //    public override double Area => PI*Dim2 * Dim1;
    //}

    #endregion

    #region  Static Method
    //internal class Utility {
    //    public int X { get; set; }
    //    public int Y { get; set; }

    //    public Utility(int _x,int _y)
    //    {
    //        X= _x;
    //        Y= _y;
    //    }
    //    public static double Area(double reduis) { return 3.14 * reduis * reduis; }

    //} 
    #endregion

    #region  Partial {class ,method }
    //internal partial class Employee {
    //    public int ID { get; set; }
    //    public string? Name { get; set; }
    //    partial int GetValue();
    //}

    #endregion


}

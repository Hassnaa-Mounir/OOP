﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4_OOP.Assg4.Project1
{
    #region Assignment4_OOP
    #region FirstProject
    //internal class Point3D :ICloneable ,IComparable
    //{
    //    public double X { get; set; }
    //    public double Y { get; set; }
    //    public double Z { get; set; }

    //    public Point3D() :this(0,0,0)
    //    {

    //    }
    //    public Point3D( double _x,double _y,double _z) 
    //    {
    //        X = _x;
    //        Y = _y;
    //        Z = _z;
    //    }

    //    public Point3D(Point3D CopyPoint) : this(CopyPoint.X, CopyPoint.Y, CopyPoint.Z) { }
    //    public override string ToString()
    //    {
    //        return $"Point Coordinates: ({X}, {Y}, {Z})";
    //    }

    //    public object Clone()
    //    {
    //        return new Point3D(this);
    //    }

    //    public int CompareTo(object? obj)
    //    {
    //        if (obj == null) return 1;
    //        Point3D other =  (Point3D) obj;
    //        if (other != null)
    //        {
    //            if (X.CompareTo(other.X) != 0) return X.CompareTo(other.X);
    //            else if (Y.CompareTo(other.Y) != 0) return Y.CompareTo(other.Y);

    //        }
    //        else { throw new ArgumentException("Object is not a Point3D"); }
    //        return 0;
    //    }

    //    public static bool operator == (Point3D p1, Point3D p2)
    //    {
    //        if (ReferenceEquals(p1, p2))
    //        {
    //            return true;
    //        }

    //        if (p1 is null || p2 is null)
    //        {
    //            return false;
    //        }

    //        return p1.X == p2.X && p1.Y == p2.Y && p1.Z == p2.Z;
    //    }

    //    public static bool operator !=(Point3D p1, Point3D p2)
    //    {
    //        return !(p1 == p2);
    //    }

    //    public override bool Equals(object? obj)
    //    {
    //        if (obj is Point3D)
    //        {
    //            return this == (Point3D)obj;
    //        }

    //        return false;
    //    }

    //    public override int GetHashCode()
    //    {
    //        return HashCode.Combine(X, Y, Z);
    //    }

    //} 
    #endregion

    #region SecondProject
    //internal class Maths {

    //    public static double Add(double a, double b)
    //    {
    //        return a + b;
    //    }

    //    public static double Subtract(double a, double b)
    //    {
    //        return a - b;
    //    }

    //    public static double Multiply(double a, double b)
    //    {
    //        return a * b;
    //    }

    //    public static double Divide(double a, double b)
    //    {
    //        if (b == 0)
    //        {
    //            throw new ArgumentException("Cannot divide by zero.");
    //        }
    //        return a / b;
    //    }
    //} 
    #endregion

    #region ThirdProject
    //public class Duration
    //{
    //    public int Hours { get; private set; }
    //    public int Minutes { get; private set; }
    //    public int Seconds { get; private set; }


    //    public Duration(int hours, int minutes, int seconds)
    //    {
    //        Hours = hours;
    //        Minutes = minutes;
    //        Seconds = seconds;
    //    }

    //    public Duration(int totalSeconds)
    //    {
    //        Hours = totalSeconds / 3600;
    //        Minutes = (totalSeconds % 3600) / 60;
    //        Seconds = totalSeconds % 60;
    //    }


    //    public override string ToString()
    //    {
    //        return $"Hours: {Hours}, Minutes: {Minutes}, Seconds: {Seconds}";
    //    }

    //    public override bool Equals(object? obj)
    //    {
    //        if (obj == null || GetType() != obj.GetType())
    //        {
    //            return false;
    //        }

    //        Duration other = (Duration)obj;
    //        return Hours == other.Hours && Minutes == other.Minutes && Seconds == other.Seconds;
    //    }


    //    public override int GetHashCode()
    //    {
    //        return HashCode.Combine(Hours, Minutes, Seconds);
    //    }


    //    public static Duration operator +(Duration d1, Duration d2)
    //    {
    //        int totalSeconds = d1.ToSeconds() + d2.ToSeconds();
    //        return new Duration(totalSeconds);
    //    }

    //    public static Duration operator +(Duration d1, int seconds)
    //    {
    //        int totalSeconds = d1.ToSeconds() + seconds;
    //        return new Duration(totalSeconds);
    //    }

    //    public static Duration operator +(int seconds, Duration d1)
    //    {
    //        int totalSeconds = seconds + d1.ToSeconds();
    //        return new Duration(totalSeconds);
    //    }


    //    public static Duration operator -(Duration d1, Duration d2)
    //    {
    //        int totalSeconds = Math.Abs(d1.ToSeconds() - d2.ToSeconds());
    //        return new Duration(totalSeconds);
    //    }


    //    public static bool operator >(Duration d1, Duration d2)
    //    {
    //        return d1.ToSeconds() > d2.ToSeconds();
    //    }

    //    public static bool operator <(Duration d1, Duration d2)
    //    {
    //        return d1.ToSeconds() < d2.ToSeconds();
    //    }


    //    public static bool operator >=(Duration d1, Duration d2)
    //    {
    //        return d1.ToSeconds() >= d2.ToSeconds();
    //    }


    //    public static bool operator <=(Duration d1, Duration d2)
    //    {
    //        return d1.ToSeconds() <= d2.ToSeconds();
    //    }


    //    public static Duration operator ++(Duration d1)
    //    {
    //        return d1 + 60; // Increase one minute
    //    }


    //    //public static Duration operator --(Duration d)
    //    //{
    //    //    return d - 60; 
    //    //}


    //    public static explicit operator DateTime(Duration d)
    //    {
    //        return new DateTime(1, 1, 1, d.Hours, d.Minutes, d.Seconds);
    //    }


    //    private int ToSeconds()
    //    {
    //        return Hours * 3600 + Minutes * 60 + Seconds;
    //    }
    //} 
    #endregion 
    #endregion


    #region  Partial {class ,method }
    //internal partial class Employee
    //{
    //    public int Salary { get; set; }
    //    partial int GetValue() { return $"Name : {Name} ,Salary {Salary}"; }
    //}

    #endregion
}

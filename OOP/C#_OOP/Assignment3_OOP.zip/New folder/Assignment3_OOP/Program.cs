﻿using Assignment3_OOP.Assignment;
using System.Xml.Linq;


namespace Assignment3_OOP
{
    internal class Program
    {

        #region Example_2

        //public static void printSeries(ISeries series) {
        //    series.Reset();
        //    for (int i = 0; i < 10; i++) {
        //        Console.Write(series.Current +"\t");
        //        series.GetNext();
        //    }
        //    Console.WriteLine();
        //    Console.WriteLine();


        //}
        #endregion
        static void Main(string[] args)
        {

            #region Demo

            #region Example _1
            //IMytype mytype = new Mytype();
            //mytype.Salary = 9000;
            //mytype.myFun();
            //mytype.print();

            #endregion


            #region Example_2
            //ISeries series = new SerieseByTwo();
            //printSeries(series);

            //ISeries series2 = new SerieseByThree();
            //printSeries(series2);

            //ISeries series3 = new SerieseByFour();
            //printSeries(series3);

            #endregion


            #region Example _3

            //IMovable movable = new Car();
            //movable.Backward();
            //movable.Right();
            //movable.forward();
            //movable.Left();

            //IFlyble flyble =new Airplan();
            //IMovable movable1 = new Airplan();


            //flyble.Backward();
            //movable1.Backward();
            //movable1.Left();
            //flyble.Left();
            //flyble.Right();
            //movable1.Right();

            #endregion


            #region ShadowCopy_DeepCopy

            //Employee emp1 = new Employee() { Id = 10, Name = "mohamed", Salary = 9000 };
            //Employee emp2 = new Employee() { Id = 20, Name = "ali", Salary = 10000 };

            //Console.WriteLine($"HashCode of emp1 = {emp1.GetHashCode()} ");
            //Console.WriteLine($"HashCode of emp2 = {emp2.GetHashCode()} ");

            //emp1 = emp2; //shalow Copy

            //Console.WriteLine("***************After shadow copy ***************");

            //Console.WriteLine($"HashCode of emp1 = {emp1.GetHashCode()} ");
            //Console.WriteLine($"HashCode of emp2 = {emp2.GetHashCode()} ");

            //////////////////////////////////////

            //Employee emp3 = new Employee() { Id = 10, Name = "mohamed", Salary = 9000 };
            //Employee emp4 = new Employee() { Id = 20, Name = "ali", Salary = 10000 };

            //Console.WriteLine($"HashCode of emp1 = {emp3.GetHashCode()} ");
            //Console.WriteLine($"HashCode of emp2 = {emp4.GetHashCode()} ");

            //emp3 = (Employee)emp4.Clone(); //Deep Copy

            //Console.WriteLine("***************After Deep copy ***************");

            //Console.WriteLine($"HashCode of emp1 = {emp3.GetHashCode()} ");
            //Console.WriteLine($"HashCode of emp2 = {emp4.GetHashCode()} ");
            #endregion

            #region BuiltIN_Interfaces
            //Employee[] employees = { new Employee{ Id = 10, Name = "mohamed", Salary = 9000 } ,
            //                        new Employee{ Id = 20, Name = "Mona", Salary = 3000 } ,
            //                         new Employee{ Id = 30, Name = "Hanaa", Salary = 7000 } };

            //Array.Sort(employees);


            //for (int i = 0; i < employees.Length; i++)
            //{
            //    Console.WriteLine(employees[i]);
            //} 
            #endregion

            #endregion


            #region Assignment3 _OOP
            #region  Part1 
            ///Q1   ----> b) To define a blueprint for a class

            ///Q2   ----> a) private

            ///Q3  -----> b) No

            ///Q4   ----> b) Yes, interfaces can inherit from multiple interfaces

            ///Q5  ----> d) implements

            ///Q6  -----> b) No

            ///Q7   -----> b) No, all members are implicitly public

            ///Q8   -----> b) To provide a clear separation between interface and class members

            ///Q9   ------>  b) No, interfaces cannot have constructors

            ///Q10  ------> c) By separating interface names with commas

            #endregion

            #region   Part 02 _Question1
            //ICircle circle = new Circle(3.5);
            //circle.DisplayShapeInfo();
            //IRectangle rectangle = new Regtangle(3,4);
            //rectangle.DisplayShapeInfo(); 
            #endregion

            #region  Part 02_ Question2

            //string userName = "Hasnaa";
            //string password ="password";
            //string role = "Admin";

            //IAuthenticationService authService = new BasicAuthenticationService();
            //bool isAuthenticateUser = authService.AuthenticateUser(userName,password);
            //Console.WriteLine($"Authentication status:  {(isAuthenticateUser? "Success" : "Failure")} ");
            //Console.WriteLine();
            //bool isAuthorizeUser = authService.AuthorizeUser(userName,role);
            //Console.WriteLine($"Authentication status:  {(isAuthorizeUser ? "Success" : "Failure")} ");
            //Console.WriteLine(); 
            #endregion

            #region  Part2_ Question3
            //string recipient = "Hasnaa mounir";
            //string message = "Your package has been delivered.";

            //INotificationService Email = new EmailNotificationService();

            //INotificationService Sms = new SmsNotificationService();

            //INotificationService PushNotify = new PushNotificationService();


            //Email.SendNotification(recipient, message);
            //Console.WriteLine();
            //Sms.SendNotification(recipient, message);
            //Console.WriteLine();
            //PushNotify.SendNotification(recipient, message);
            //Console.WriteLine();
            //Console.WriteLine(); 
            #endregion
            #endregion
        }
    }
}

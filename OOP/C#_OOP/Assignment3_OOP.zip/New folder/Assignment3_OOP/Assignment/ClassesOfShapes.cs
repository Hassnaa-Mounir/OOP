﻿using System.Collections;

namespace Assignment3_OOP.Assignment
{
    #region Demo

    #region Example_1
    //internal class Mytype : IMytype
    //{
    //    public int Salary { get; set; }

    //    public void myFun()
    //    { Console.WriteLine("Hello Route"); }
    //}


    #endregion


    #region Example_2

    //internal class SerieseByTwo : ISeries
    //{
    //    public int Current { get ; set ; }

    //    public void GetNext()
    //    {
    //        Current += 2;
    //    }

    //    public void Reset()
    //    {
    //       Current = 0;
    //    }
    //}

    //internal class SerieseByThree : ISeries
    //{
    //    public int Current { get; set; }

    //    public void GetNext()
    //    {
    //        Current += 3;
    //    }

    //    public void Reset()
    //    {
    //        Current = 0;
    //    }
    //}

    //internal class SerieseByFour : ISeries
    //{
    //    public int Current { get ; set; }

    //    public void GetNext()
    //    {
    //        Current += 4;
    //    }

    //    public void Reset()
    //    {
    //        Current = 0;
    //    }
    //}
    #endregion


    #region Example _3
    //internal class Car : IMovable
    //{
    //    public void Backward()
    //    {
    //        Console.WriteLine("Backward rule of moveable for car");
    //    }

    //    public void forward()
    //    {
    //        Console.WriteLine("Forward rule of moveable for car");
    //    }

    //    public void Left()
    //    {
    //        Console.WriteLine("left rule of moveable for car");
    //    }

    //    public void Right()
    //    {
    //        Console.WriteLine("Right rule of moveable for car");
    //    }
    //}

    //internal class Airplan : IMovable, IFlyble   // Explicit implement
    //{
    //    void IMovable.Backward()
    //    {
    //        Console.WriteLine("Backward rule of moveable for Airplan");
    //    }

    //    void IFlyble.Backward()
    //    {
    //        Console.WriteLine("Backward rule of Flyable for Airplan");
    //    }

    //    void IMovable.forward()
    //    {
    //        Console.WriteLine("forward rule of moveable for Airplan");
    //    }

    //    void IFlyble.forward()
    //    {
    //        Console.WriteLine("forward rule of Flyable for Airplan");
    //    }
    //    void IMovable.Left()
    //    {
    //        Console.WriteLine("left rule of moveable for Airplan");
    //    }

    //    void IFlyble.Left()
    //    {
    //        Console.WriteLine("left rule of Flyable for Airplan");
    //    }

    //    void IMovable.Right()
    //    {
    //        Console.WriteLine("Right rule of moveable for Airplan");
    //    }

    //    void IFlyble.Right()
    //    {
    //        Console.WriteLine("Right rule of Flyable for Airplan");
    //    }
    //}

    #endregion

    #region BuiltIN _ Interface

    //internal class Employee : ICloneable  ,IComparable ,IComparer
    //{
    //    private int id;

    //    public int Id
    //    {
    //        get { return id; }
    //        set { id = value; }
    //    }

    //    private string name;

    //    public string Name
    //    {
    //        get ;
    //        set ;
    //    }

    //    private decimal salary;

    //    public  decimal Salary
    //    {
    //        get { return salary; }
    //        set { salary = value; }
    //    }

    //    public Employee()
    //    {
            
    //    }

    //    public Employee(int id ,string name ,decimal salary)
    //    {
    //        Id = id;
    //        Name = name;
    //        Salary = salary;
    //    }

    //    public Employee(Employee CopyEmp)
    //    {
    //        this.Id = CopyEmp.Id;
    //        this.Name = CopyEmp.Name;
    //        this.Salary = CopyEmp.Salary;
    //    }

    //    public override string ToString()
    //    {
    //        return $"ID : {Id} ,Name : {Name} ,Salary : {Salary}";
    //    }

    //    public object Clone()
    //    {
    //      //  return new Employee() { id=this.Id ,Name=this.Name ,Salary=this.Salary };

    //        return new Employee(this);
    //    }

    //    public int CompareTo(object? obj)
    //    {
    //        Employee ComparedEmp = (Employee?)obj;
    //        return this.Salary.CompareTo(ComparedEmp?.Salary);
    //    }

    //    public int Compare(object? x, object? y)
    //    {
    //        Employee? EmpX = (Employee?)x;
    //        Employee? EmpY = (Employee?)y;
    //        return EmpX?.id.CompareTo(EmpY?.id)?? (EmpY is null ? 0 : -1);


    //    }
    //} 


    #endregion

    #endregion

    #region Assignment3 _OOP
    #region   Part 02 _Question1
    //internal class Circle : ICircle
    //{

    //    public double Radius
    //    {
    //        get;
    //        set;
    //    }
    //    public double Area { get { return Math.PI * Radius * Radius; } set { } }

    //    public Circle(double radius)
    //    {
    //        Radius = radius;
    //    }


    //    public void DisplayShapeInfo()
    //    {
    //        Console.WriteLine($"Circle with Radius: {Radius}, Area: {Area}");
    //    }
    //}

    //internal class Regtangle : IRectangle
    //{
    //    public double Width { get; set; }
    //    public double Length { get; set; }
    //    public double Area { get { return Length * Width; } set { } }

    //    public Regtangle(double length, double width)
    //    {
    //        Length = length;
    //        Width = width;
    //    }
    //    public void DisplayShapeInfo()
    //    {
    //        Console.WriteLine($"Rectangle with Length: {Length}, Width: {Width}, Area: {Area}");
    //    }
    //}

    #endregion


    #region Part 02_ Question2
    //internal class BasicAuthenticationService : IAuthenticationService
    //{
    //    private string StoredUserName="Hasnaa";
    //    private string StoredPassword = "password";
    //    private string StoredRole = "Guest";
    //    public bool AuthenticateUser(string userName,string password)
    //    {
    //       if( userName==StoredUserName && password==StoredPassword ) { return true; }
    //       else { return false; }
    //    }

    //    public bool AuthorizeUser(string userName, string role)
    //    {
    //        if (userName == StoredUserName && role == StoredRole) { return true; }
    //        else { return false; }
    //    }
    //} 
    #endregion


    #region  Part2_ Question3
    //internal class EmailNotificationService : INotificationService
    //{
    //    public void SendNotification(string recipient, string message)
    //    {
    //        Console.WriteLine($"Sending email notification to {recipient}: {message}");
    //    }
    //}

    //internal class SmsNotificationService : INotificationService
    //{
    //    public void SendNotification(string recipient, string message)
    //    {
    //        Console.WriteLine($"Sending SMS notification to {recipient}: {message}");
    //    }
    //}
    //internal class PushNotificationService : INotificationService
    //{
    //    public void SendNotification(string recipient, string message)
    //    {
    //        Console.WriteLine($"Sending push notification to {recipient}: {message}");
    //    }
    //} 
    #endregion
    #endregion




}

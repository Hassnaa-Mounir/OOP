﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3_OOP.Assignment
{


    #region Demo

    #region Example_1
    //internal interface IMytype
    //{

    //    public int Salary { get; set; }

    //    public void myFun();
    //    public void print() { Console.WriteLine("print function with default implementation to IMytype"); }

    //} 
    #endregion


    #region Example_2

    //internal interface ISeries 
    //{
    //    public int Current { get; set; }
    //    public void GetNext();

    //    public void Reset();
    //}


    #endregion



    #region Example _3

    //internal interface IMovable {
    //    public void forward();
    //    public void Backward();
    //    public void Right();
    //    public void Left();
    //}
    //internal interface IFlyble
    //{
    //    public void forward();
    //    public void Backward();
    //    public void Right();
    //    public void Left();
    //}
    #endregion



    #endregion


    #region Assignment3 _OOP
    #region  Part 02 _Question1
    //internal interface IShape
    //{
    //    public double Area { get; set; }
    //    public void DisplayShapeInfo();
    //}

    //internal interface ICircle : IShape
    //{
    //    public double Radius { get; set; }
    //}
    //internal interface IRectangle : IShape
    //{
    //    public double Width { get; set; }
    //    public double Length { get; set; }
    //}

    #endregion


    #region  Part 02_ Question2
    //internal interface IAuthenticationService
    //{

    //    public bool AuthenticateUser(string userName, string password);
    //    public bool AuthorizeUser(string userName, string role);


    //} 
    #endregion


    #region  Part2_ Question3
    //internal interface INotificationService {

    //    public void SendNotification(string recipient,string message);


    //} 
    #endregion
    #endregion


}
